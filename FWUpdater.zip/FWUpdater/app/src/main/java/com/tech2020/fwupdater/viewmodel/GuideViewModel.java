package com.tech2020.fwupdater.viewmodel;

import android.arch.lifecycle.ViewModel;

public class GuideViewModel extends ViewModel {

}
